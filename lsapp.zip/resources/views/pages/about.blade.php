@extends('layouts.app')

@section('content')
        <h1>{{$title}}</h1>
        <p>This is about page</p>
@endsection