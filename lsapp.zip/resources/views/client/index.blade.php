@extends('mainlayouts.app')

@section('content')
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                <div class="card-header">Welcome, {{Auth::user()->username}}</div>
                   <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif
                        <h3>Manage Clients</h3>
                        <div><a href="#" class="show-modal create-modal btn btn-primary">New Client</a></div>
                        <br>
                        <input type="text" name="search" id="search" class="form-control" placeholder="Search using Client ID"/>
                        <br>
                        <table class="table table-striped">
                            <tr>
                                <th>Client Name</th>
                                <th>Client Email</th>
                                <th>Client ID</th> 
                                <th></th>
                                <th></th>
                            </tr>
                            @foreach($users as $user)
                            <tr>
                                <td>{{$user->username}}</td>
                                <td>{{$user->email}}</td>
                                <td>{{$user->id}}</td>
                                <td><span style="display:flex; justify-content:flex-end; width:190%; padding:0;"> 
                                <a href="/users/{{$user->id}}/customersedit" data-target-id="1" class="fa fa-eye show-modal btn btn-info"></a></span></td> 
                                <td></td>
                             
                            </tr>
                            @endforeach
                        </table>   
                     <div class="text-center">
                            {!! $users->links(); !!}  <!--pagination-->
                      </div>

     {{-- Modal Form Show POST --}}


<!--<div id="show" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"></h4>
                  </div>
                    <div class="modal-body">
                      <p>Customer ID : {{$user->id}}</p>
                      <p>Customer Name : {{$user->username}}</p>
                    </div>
                    <div class="modal-footer">
                    <button type="button" class="btn btn-info" data-dismiss="modal">
                    <span class="glyphicon glyphicon-remove"></span>Close</button>
                    </div>
                    </div>
                    </div>
                  </div> -->
          </div>
        </div>
     </div>
    </div>
@endsection
