<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateClientsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('clients', function (Blueprint $table) {
            $table->increments('client_id');
            $table->string('c_fname');
            $table->string('c_lname');
            $table->varchar('phone')->unique();
            $table->varchar('business phone')->nullable();
            $table->string('client sn')->unique();
            $table->string('division');
            $table->string('district');
            $table->string('upazilla');
            $table->string('union');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('clients');
    }
}
