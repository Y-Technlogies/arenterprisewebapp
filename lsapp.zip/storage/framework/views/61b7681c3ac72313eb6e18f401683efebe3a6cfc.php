<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
            <div class="card-header">Welcome, <?php echo e(Auth::user()->username); ?></div>
               <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <div><a href="/posts/create" class="btn btn-primary">Create Client</a></div>
                    <br>
                    <h3>Your logged posts</h3>
                    <table class="table table-striped">
                        <tr>
                            <th>Client Name</th>
                            <th>Client Email</th>
                            <th>Client ID</th>
                        </tr>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->username); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->id); ?></td>
                            <td><span style="display:flex; justify-content:flex-end; width:190%; padding:0;">
                           <!-- <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-info">Edit</a></span></td>
                            -->
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mainlayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/client.blade.php ENDPATH**/ ?>