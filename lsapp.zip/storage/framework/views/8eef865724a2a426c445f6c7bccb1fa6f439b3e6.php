<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                <div class="card-header">Welcome, <?php echo e(Auth::user()->username); ?></div>
                   <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <h3>Manage Clients</h3>
                        <div><a href="#" class="show-modal create-modal btn btn-primary">New Client</a></div>
                        <br>
                        <input type="text" name="search" id="search" class="form-control" placeholder="Search using Client ID"/>
                        <br>
                        <table class="table table-striped">
                            <tr>
                                <th>Client Name</th>
                                <th>Client Email</th>
                                <th>Client ID</th> 
                                <th></th>
                                <th></th>
                            </tr>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->username); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->id); ?></td>
                                <td><span style="display:flex; justify-content:flex-end; width:190%; padding:0;"> 
                                <a href="/users/<?php echo e($user->id); ?>/customersedit" data-target-id="1" class="fa fa-eye show-modal btn btn-info"></a></span></td> 
                                <td></td>
                             
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>   
                     <div class="text-center">
                            <?php echo $users->links();; ?>  <!--pagination-->
                      </div>

     


<!--<div id="show" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"></h4>
                  </div>
                    <div class="modal-body">
                      <p>Customer ID : <?php echo e($user->id); ?></p>
                      <p>Customer Name : <?php echo e($user->username); ?></p>
                    </div>
                    <div class="modal-footer">
                    <button type="button" class="btn btn-info" data-dismiss="modal">
                    <span class="glyphicon glyphicon-remove"></span>Close</button>
                    </div>
                    </div>
                    </div>
                  </div> -->
          </div>
        </div>
     </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mainlayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/client/index.blade.php ENDPATH**/ ?>